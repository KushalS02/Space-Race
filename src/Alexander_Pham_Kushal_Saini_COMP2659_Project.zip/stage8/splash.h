/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: splash.h

Instructor: Paul Pospisil

*/
#ifndef SPLASH_H
#define SPLASH_H

#include "TYPES.H"
#include "const.h"

/*
the splash screen bitmap
*/
extern UINT32 splashScreen[];

#endif