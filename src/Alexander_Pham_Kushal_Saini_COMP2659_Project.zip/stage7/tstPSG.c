/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: tstPSG.c

Instructor: Paul Pospisil

*/
#include "psg.h"

int main() {

    int i;

    for(i = 0; i < 1000000; i++) {

        startMusic();
    }
   

    return 0;

}