/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: ikbd.h

Instructor: Paul Pospisil

*/
#ifndef IKBD_H
#define IKBD_H

/*
    Function: ikbdISR

    Purpose: creates the keyboard interrupt
*/
void ikbdISR();

#endif
