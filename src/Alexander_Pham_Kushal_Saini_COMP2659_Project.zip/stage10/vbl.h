/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: vbl.h

Instructor: Paul Pospisil

*/
#ifndef VBL_ISR_H
#define VBL_ISR_H

/*
    Function: vblISR

    Purpose: request a VBL interrupt
*/
void vblISR();

#endif