/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: endGame.h

Instructor: Paul Pospisil

*/
#ifndef END_GAME_SCREEN_H
#define END_GAME_SCREEN_H

#include "TYPES.H"
#include "const.h"

extern UINT32 endGameScreen[];

#endif