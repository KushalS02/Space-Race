/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: 

Instructor: Paul Pospisil

*/
#ifndef CLEAR_QK_H
#define CLEAR_QK_H

/*
Name: clearQuick

Purpose: clears only a section of the screen 

Input: void *base - screen to be cleared
*/
void clearQuick(void *base);

#endif