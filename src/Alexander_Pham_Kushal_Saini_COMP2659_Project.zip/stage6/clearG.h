/*
Authours: Alexander Pham and Kushal Saini

Course: COMP 2659 - 001 

File name: clearG.h

Instructor: Paul Pospisil

*/
#ifndef CLEAR_GAME_H
#define CLEAR_GAME_H

/*

Name: clearG

Purpose: clear the entire screen

Input: void base* - the screen to be cleared

*/
void clearG(void *base);

#endif